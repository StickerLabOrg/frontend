import React from "react";
import ReactDOM from "react-dom/client";
import App from "./routes/AppRoutes";

import { AuthProvider } from "./context/AuthContext";
import { UserProvider } from "./context/UserContext";

import "./index.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <AuthProvider>
      <UserProvider>
        <App />
      </UserProvider>
    </AuthProvider>
  </React.StrictMode>
);
