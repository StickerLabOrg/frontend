import { Link, useLocation } from "react-router-dom";
import { Home, Book, BarChart2, ShoppingBag, User, LogOut } from "lucide-react";

export function Sidebar() {
  const { pathname } = useLocation();

  const menu = [
    { label: "Dashboard", icon: <Home size={18} />, path: "/" },
    { label: "Meu Álbum", icon: <Book size={18} />, path: "/album" },
    { label: "Classificação", icon: <BarChart2 size={18} />, path: "/classificacao" },
    { label: "Ranking", icon: <BarChart2 size={18} />, path: "/ranking" },
    { label: "Loja", icon: <ShoppingBag size={18} />, path: "/loja" },
    { label: "Perfil", icon: <User size={18} />, path: "/perfil" },
  ];

  return (
    <aside className="h-screen w-64 bg-[#121826] text-white fixed left-0 top-0 flex flex-col p-6 gap-6">

      {/* Título */}
      <div>
        <h1 className="text-2xl font-semibold">Hub do Torcedor</h1>
        <p className="text-sm text-gray-400 mt-1">Olá, Torcedor</p>

        <div className="mt-3 bg-[#1F293B] py-1 px-2 w-max text-green-400 rounded">
          Moedas <span className="font-bold">1250</span>
        </div>
      </div>

      {/* Navegação */}
      <nav className="flex-1 flex flex-col gap-2">
        {menu.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center gap-3 px-3 py-2 rounded-lg transition
              ${pathname === item.path ? "bg-green-500 text-black font-semibold" : "text-gray-300 hover:bg-[#1F293B]"}`}
          >
            {item.icon}
            {item.label}
          </Link>
        ))}
      </nav>

      {/* Botão sair */}
      <button className="flex items-center gap-2 text-red-400 hover:text-red-300">
        <LogOut size={18} /> Sair
      </button>

    </aside>
  );
}
