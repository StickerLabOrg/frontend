// src/pages/Dashboard/DashboardPage.tsx

import { useEffect, useState } from "react";
import axios from "axios";
import { AppLayout } from "../../layout/AppLayout";
import { Card, CardContent } from "../../components/ui/card";
import { Button } from "../../components/ui/button";

/* -------------------------------------------------------
   TYPES
------------------------------------------------------- */

type Team = {
  id: string;
  nome: string;
  escudo: string;
};

type Match = {
  id_partida: string;
  time_casa: Team;
  time_fora: Team;
  data: string;
  horario: string;
};

/* -------------------------------------------------------
   FORMATADOR DE DATA E HORA
------------------------------------------------------- */

function formatarDataHora(dataISO: string, horario: string) {
  try {
    const [year, month, day] = dataISO.split("-");
    const [h, m] = horario.split(":");

    const dataObj = new Date(
      Number(year),
      Number(month) - 1,
      Number(day),
      Number(h),
      Number(m)
    );

    const dataBR = dataObj.toLocaleDateString("pt-BR");
    const horaBR = dataObj.toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    });

    return `${dataBR} — ${horaBR}`;
  } catch (e) {
    return "Data inválida";
  }
}

/* -------------------------------------------------------
   COMPONENTE
------------------------------------------------------- */

export function DashboardPage() {
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  async function fetchMatches() {
    try {
      const response = await axios.get("http://localhost:8000/partidas/proximas");

      const partidasOrdenadas = response.data.sort(
        (a: Match, b: Match) =>
          new Date(`${a.data}T${a.horario}`).getTime() -
          new Date(`${b.data}T${b.horario}`).getTime()
      );

      setMatches(partidasOrdenadas);
    } catch (err) {
      console.error("Erro ao buscar partidas:", err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchMatches();
  }, []);

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto w-full">

        {/* Cabeçalho */}
        <h1 className="text-4xl font-bold text-primary mb-2">Dashboard</h1>
        <p className="text-mutedForeground mb-8">
          Visão geral dos seus palpites e partidas futuras.
        </p>

        {/* CARDS DE MÉTRICAS */}
        <section className="grid gap-4 md:grid-cols-4 mb-10">
          {[
            { titulo: "Total de Palpites", valor: "0" },
            { titulo: "Taxa de Acerto", valor: "0%" },
            { titulo: "Pontos Ganhos", valor: "0" },
            { titulo: "Figurinhas coletadas", valor: "0" },
          ].map((item, idx) => (
            <Card
              key={idx}
              className="
                bg-white/5 
                border border-white/10
                backdrop-blur-md
                shadow-lg shadow-black/30
                text-white h-[110px]
                rounded-xl
              "
            >
              <CardContent className="p-4 flex flex-col justify-center">
                <p className="text-xs text-gray-300">{item.titulo}</p>
                <p className="text-2xl font-bold text-emerald-400 mt-1">
                  {item.valor}
                </p>
              </CardContent>
            </Card>
          ))}
        </section>

        {/* LISTA DE PARTIDAS */}
        <h3 className="text-xl font-semibold mb-4">Próximas Partidas</h3>

        {loading && <p className="text-gray-300">Carregando partidas...</p>}

        <section className="space-y-4">
          {matches.map((match) => (
            <Card
              key={match.id_partida}
              className="
                bg-white/5
                border border-white/10
                backdrop-blur-md
                shadow-xl shadow-black/40
                text-white h-[150px]
                rounded-xl
              "
            >
              <CardContent className="py-4 px-6 flex flex-col md:flex-row items-center justify-between">

                {/* Times */}
                <div className="flex-1 flex flex-col sm:flex-row items-center justify-center gap-10">

                  {/* CASA */}
                  <div className="flex items-center gap-3">
                    <img
                      src={match.time_casa.escudo}
                      className="h-10 w-10 rounded-full object-cover"
                      onError={(e) => (e.currentTarget.src = "/default-team.png")}
                    />
                    <div>
                      <p className="font-semibold">{match.time_casa.nome}</p>
                      <p className="text-xs text-gray-300">Casa</p>
                    </div>
                  </div>

                  {/* VS */}
                  <span className="text-3xl font-bold">VS</span>

                  {/* FORA */}
                  <div className="flex items-center gap-3">
                    <img
                      src={match.time_fora.escudo}
                      className="h-10 w-10 rounded-full object-cover"
                      onError={(e) => (e.currentTarget.src = "/default-team.png")}
                    />
                    <div className="text-right">
                      <p className="font-semibold">{match.time_fora.nome}</p>
                      <p className="text-xs text-gray-300">Visitante</p>
                    </div>
                  </div>
                </div>

                {/* DATA / BOTÃO */}
                <div className="flex flex-col items-center gap-2 w-36">
                  <span className="text-xs text-gray-300">
                    {formatarDataHora(match.data, match.horario)}
                  </span>

                  <Button className="bg-emerald-500 hover:bg-emerald-600 text-black font-semibold w-full">
                    Palpitar
                  </Button>
                </div>

              </CardContent>
            </Card>
          ))}
        </section>

      </div>
    </AppLayout>
  );
}
